# Direct human EEG and pain evidence

## Key Facts

- Curated **21 linked records**: 16 papers and 5 dataset records, focused on human pain EEG, subjective pain reports, single-trial evoked responses, tonic oscillations, prediction, and public EEG resources.
- Single-trial laser-evoked potentials (LEPs), especially N2/P2 features, are directly associated with trial pain ratings. Huang et al. (2013) report within-person versus cross-person performance differences (binary accuracy 86.3% vs 80.3%; continuous pain MAE 1.03 vs 1.82), but their full paper was not verified as open access here. The open-access 2018 interstimulus-EEG study reports cross-person MAE improvement from 1.36 to 1.19.
- The literature distinguishes physical stimulus intensity from subjective pain: Nickel et al. (2017) report sensorimotor alpha/beta associations with stimulus intensity and medial-prefrontal gamma with pain ratings during tonic heat. These are association statistics, not held-out prediction scores.
- Evoked LEP amplitudes are not automatically pain-specific: Iannetti et al. (2008) show repetition/salience sensitivity. Zhang et al. (2012) report SI gamma tracks pain intensity despite repetition, indicating the ERP and induced/source-localized gamma findings need separate tests.
- Tonic alpha findings are promising but context-limited. Nir et al. (2012) report alpha-1 relationships to tonic pain ratings; May et al. (2025) found no consistent predictive value for peak alpha frequency in brief laser pain across two sessions.
- Public EEG resources with article-verified links include Zhao et al.'s 678-participant nine-OpenNeuro LEP collection, the OSF gamma pain/touch dataset jw8rv, OSF s75q6, OSF z2h86, and OSF bsv86. Some cohorts may overlap: z2h86 metadata cites the May PAF paper as its first related publication even though the papers link different OSF projects and analyze different N; deduplicate before combining.

## Notable Claims Requiring Cross-Reference

- **Pain versus salience:** Iannetti et al. (2008) challenge interpreting repeated-stimulus vertex LEPs as pain-specific. Zhang et al. (2012) report a distinct gamma-band pain relationship. These are different responses and should not be summarized as one agreed neural marker.
- **Tonic versus brief-pain alpha:** Nir et al. (2012) and earlier tonic-pain claims do not establish brief-pain generalization; May et al. (2025) directly report a null/inconsistent PAF relation for brief laser pain.
- **Gamma reliability and artifacts:** Nickel et al. (2017) and Zhang et al. (2012) report pain-linked gamma in different locations/paradigms; Dowman et al. (2008) warn that apparent scalp gamma can be EMG artifact; Valentini et al. (2023) report high interindividual variability and non-universal gamma responses.
- **Dataset overlap:** Both s75q6 and z2h86 are linked in primary articles, while the z2h86 OSF record cites the May 2025 article. Do not treat them as independent cohorts until participant manifests and README files are reconciled.
- **Target semantics:** pain onset/presence, pain discriminability, low/high classification, stimulus intensity, and continuous subjective rating are distinct targets. Compare validation only after matching target definitions and participant-held-out splits.

## Source Quality Assessment

- Priority was given to primary journal articles, PubMed abstracts where full text was unavailable, and primary OSF/OpenNeuro records. Article-to-dataset ties are included only where a paper or repository explicitly supports the link.
- The open full-text sources include the Hu 2011 LEP method, Iannetti 2008 salience study, Zhang 2012 gamma study, Nickel 2017 tonic EEG study, Dowman 2008 tonic study, Sun 2020 detector, Segning 2022 CVUE proof-of-concept, Valentini 2023 gamma stability study, May 2025 PAF study, Tiemann 2026 replication study, Zhao 2025 dataset paper, and 2022 pain-discriminability paper.
- Huang 2013 has a verified publisher abstract and reported metrics, but full text/open-access status is not verified. Babiloni 2008 and Nir 2012 are limited to accessible abstracts/records in this evidence set. Their narrower claims are labeled accordingly; no data-access status is inferred.
- Association significance is not presented as predictive accuracy. Where an inspected abstract did not give a numerical metric, the JSON says so explicitly. Public repositories are called public EEG only when accessible project/data records and an article relationship were verified.

## Gaps & Unanswered Questions

- The target pipeline uses only C3/C4/Cz, 128-Hz sampling, a 1–40-Hz filter, and five-second windows. This cannot test most high-gamma findings (band components above 40 Hz removed; Nyquist 64 Hz), and omits temporal, FC5/T7, medial prefrontal, and broad source-localized features.
- Five-second windows do not reproduce ten-minute tonic pain or longer resting PAF estimation. LEP modeling requires reliable event triggers, trial epochs, and a prestimulus baseline; the pipeline's fixed windows must be mapped to those timing requirements.
- Several canonical historical prediction papers lack a verified open raw-EEG link in this focused search. Huang full methods and leakage-safe split details remain unverified from accessible full text; Babiloni's abstract tests evoked amplitude rather than pain-rating prediction.
- The large OpenNeuro collection comprises multiple experiments with different systems/protocols. Sampling rate, channels, reference, units, and event coding need accession-level review before inclusion.
- Reconcile possible s75q6/z2h86 cohort overlap and verify whether independent replication cohorts are included in each public repository.

## Sources

Primary evidence excerpts and source URLs are recorded in the JSON sources array. Evidence Markdown is under research/sources/pain-evidence/. Key starting points:

- Hu et al. 2011 LEP method: https://pmc.ncbi.nlm.nih.gov/articles/PMC3234084/
- Iannetti et al. 2008 laser salience: https://pmc.ncbi.nlm.nih.gov/articles/PMC2525705/
- Zhang et al. 2012 gamma: https://www.jneurosci.org/content/32/22/7429
- Nickel et al. 2017 tonic EEG: https://pmc.ncbi.nlm.nih.gov/articles/PMC5349759/
- May et al. 2025 PAF: https://pmc.ncbi.nlm.nih.gov/articles/PMC12363489/
- Tiemann et al. 2026 replication: https://journals.plos.org/plosbiology/article?id=10.1371/journal.pbio.3003948
- Zhao et al. 2025 LEP data descriptor: https://pmc.ncbi.nlm.nih.gov/articles/PMC12405539/
- Acute pain EEG OSF: https://osf.io/bsv86/

## JSON path

research/pain-evidence.json
